import time
import subprocess

ping_address = "lincoln.ac.uk"  #no https
interval = 3  #seconds

print("Starting detection")

# Function to ping and get detailed connection information
def ping(address):
    try:
        output = subprocess.check_output(["ping", address, "-n", "1"], universal_newlines=True)
        packets_sent = 0
        packets_received = 0
        packets_lost = 0
        response_time = None

        for line in output.split("\n"):
            if "time=" in line:
                response_time = float(line.split("time=")[1].split("ms")[0].strip())
                packets_received = 1
            elif "Packets:" in line:
                parts = line.split(", ")
                packets_sent = int(parts[0].split(" = ")[1])
                packets_received = int(parts[1].split(" = ")[1])
                packets_lost = int(parts[2].split(" = ")[1].split(" ")[0])

        packets_lost = packets_sent - packets_received
        return packets_sent, packets_received, packets_lost, response_time
    except subprocess.CalledProcessError:
        return None, None, None, None

def check_ddos():
    previous_packet_loss = None

    while True:
        packets_sent, packets_received, packets_lost, response_time = ping(ping_address)
        current_packet_loss = packets_lost is None or packets_lost > 0

        if previous_packet_loss is not None and previous_packet_loss != current_packet_loss:
            message = f"packet loss status changed. current status: {'packet loss' if current_packet_loss else 'no packet loss'}"
            print(message)

        if response_time is not None:
            print(f"pinging {ping_address}... current ping: {response_time:.2f} ms | packets sent: {packets_sent}, received: {packets_received}, lost: {packets_lost}")
        else:
            print(f"pinging {ping_address}... no response (packet loss likely) | packets sent: {packets_sent}, received: {packets_received}, lost: {packets_lost}")

        previous_packet_loss = current_packet_loss
        time.sleep(interval)

if __name__ == "__main__":
    check_ddos()
